const express  =  require('express');//const because it doesnt change
const path = require('path');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const http = require('http');

mongoose.connect('mongodb://localhost/nodekb')
let db = mongoose.connection;

db.once('open',function(){
  console.log("connected to mongodb");
})

//check for errors
db.on('error',function(){
  console.log(err)
});

let Bathroom = require('./models/bathroom');
//init app
const app = express();

app.set('views', path.join (__dirname, 'views'));
//app.set('view engine', 'html');

//body parser middlewear
app.use(bodyParser.urlencoded({exteded:false}));
app.use(bodyParser.json());

//set public folder
app.use(express.static(path.join(__dirname, 'public')));





//home route
app.get('/', function(req, res){
  Bathroom.find({},function(err,bathrooms){
    if(err){
      console.log(err);
    } else{
      //res.sendFile('./views/layout.html',{
      res.sendFile(path.join(__dirname + '/views/index.html'));
    }
  });
});

//add to map route
app.get('/bathroom/add', function(req, res){
  res.sendFile(path.join(__dirname + '/views/add_bathroom.html'));
});

app.post('/bathroom/add', function(req,res){
  let bathroom = new Bathroom();
  bathroom.name = req.body.name;
  bathroom.address= req.body.address;
  bathroom.save(function(err){
    if(err){
      console.log(err);
    } else {
      res.redirect('/');
    }
  })
  console.log(req.body.name)
  return;
});

//add bathroom
app.get('/bathroom/:id', function(req,res){
  Bathroom.findById(req.params.id,function(err,bathroom){
    res.render('bathroom',{
      bathroom:bathroom
    });
    return;
  });
});

//Load edit form
app.get('/bathroom/edit/:id', function(req,res){
  Bathroom.findById(req.params.id,function(err,bathroom){
    res.render('edit_bathroom',{
      bathroom:bathroom
    });
    return;
  });
});

//post an update in edit_bathroom
app.post('/bathroom/edit/:id', function(req,res){
  let bathroom = {};
  bathroom.name = req.body.name;
  bathroom.address= req.body.address;

  let query = {_id:req.params.id}

  Bathroom.update(query,bathroom,function(err){
    if(err){
      console.log(err);
    } else {
      res.redirect('/');
    }
  })
  console.log(req.body.name)
  return;
});

app.delete('/bathroom/:id',function(req,res){
  let query = {_id:req.params.id}
  Bathroom.remove(query,function(err){
    if(err){
      console.log(err);
    }
    res.send('Success')
  });
});



//home route
app.listen(3000,function(){
  console.log('Server started on 3000');
});
