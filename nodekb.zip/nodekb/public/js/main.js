//globalize marker and infowindow to only have 1 at a time.
var marker;
var infoWindow;
$(document).ready(function () {
    initCoords();
});



//------- ADDING A BATHROOM -------------------
function addBathroom(person){
  console.log("adding a batroom" + person);

}



//----GEOCODING: takes address and outputs info------------------
function geocode(coords){
  addMarker(coords);


  var loc="";
  var placeID;
  loc = coords;
  axios.get('https://maps.googleapis.com/maps/api/geocode/json',{
    params:{
      latlng:coords.toUrlValue(),
      key:'AIzaSyBgWwz_cVdLp0SRSGACXjyQoOWE6A4ZDf8'
    }
  })
  .then(function(response){
    // log response
    //console.log(response.data.results[0].formatted_address);
    console.log(response.data.results);
    var open;
    var request = {
      placeId: response.data.results[0].place_id
    };
    //New service
    service = new google.maps.places.PlacesService(map);
    service.getDetails(request, callback);
  //get info with placeid
    function callback(place, status) {
      if (status == google.maps.places.PlacesServiceStatus.OK) {
        // console.log("geo.loc: " + place.geometry.location);
        // console.log("formatted address:  " + place.formatted_address);
        // console.log("placeid:  " + place.place_id);
        // console.log("name"+ place.name);
      }
    }

    document.getElementById("responseAddress").innerHTML = response.data.results[0].formatted_address;
    var infoDiv = document.getElementById("infoWindowDiv");
    infoWindow.setContent(
      infoDiv
    );
  })
  .catch(function(error){
    console.log(error);
  });
}





// ---------add marker functions-----------------------------------------
function showUser(map, props){

}

function addMarker(props){
    marker.setPosition(props);
    //geocode(coords);
  infoWindow.open(map, marker);
}


//---------AutoComplete Search--------------------------------------
function initAutocomplete(map) {

  // Create the search box and link it to the UI element.
  var input = document.getElementById('pac-input');
  var searchBox = new google.maps.places.SearchBox(input);
  //map.controls[google.maps.ControlPosition.BOTTOM_RIGHT].push(input);
  // Bias the SearchBox results towards current map's viewport.
  map.addListener('bounds_changed', function() {
    searchBox.setBounds(map.getBounds());
  });

  var markers = [];

  // Listen for the event fired when the user selects a prediction and retrieve
  // more details for that place.
  searchBox.addListener('places_changed', function() {
    console.log("in searchbox listener");
    var places = searchBox.getPlaces();

    if (places.length == 0) {
      return;
    }

    // Clear out the old markers.
    markers.forEach(function(marker) {
      marker.setMap(null);
    });

    // For each place, get the icon, name and location.
    var bounds = new google.maps.LatLngBounds();
    places.forEach(function(place) {
      if (!place.geometry) {
        console.log("Returned place contains no geometry");
        return;
      }

      //HAVE THE SEARCHED place
      console.log("place_id" + place.place_id);
      console.log("place name"+ place.name);
      console.log("place hours"+ place.opening_hours.open_now);




      if (place.geometry.viewport) {
        // Only geocodes have viewport.
        bounds.union(place.geometry.viewport);
      } else {
        bounds.extend(place.geometry.location);
      }
    });
    map.fitBounds(bounds);
  });
}




//-----------Create the map---------------------------------------
function initMap(position){
  var options = {
    zoom:16,
    center:{lat: -33.8660001, lng: 151.2014246},
    //clickableIcons: false // disables default POI
  }
  //creates our singular map and marker
  map = new google.maps.Map(document.getElementById('map'), options);
  infoWindow = new google.maps.InfoWindow({
    content:""
  });
  marker = new google.maps.Marker({
    position:{},
    map:map,
    //icon:props.iconImage
  });
  userMarker = new google.maps.Marker({
    position:{},
    map:map,
  });
  //Watch users current position
  var watch = navigator.geolocation.watchPosition(watchMap,watchError);
  function watchMap(position){
    var currPosition;
    // if they allowed location
    map.setCenter(position.coords);
    if(position.coords){
      currPosition = {lat:position.coords.latitude,lng:position.coords.longitude}
      map.setCenter(currPosition);
    } else {
      console.log("Starting in Sydney");
    }

    //Center map button
    document.getElementById("centerMapBtn").onclick = function(){
      map.setCenter(currPosition);
    }
  }

function watchError(err){
  console.warn('ERROR(' + err.code + '): ' + err.message);
}

  // Listen for click on map
  google.maps.event.addListener(map, 'click', function(event){
    geocode(event.latLng);
  });
  //Call autocomplete for search bar
   initAutocomplete(map);
  //for map button
  map.controls[google.maps.ControlPosition.BOTTOM_LEFT].push(document.getElementById('centerMapDiv'));
}//end function initmap

//------ initial call with navigator------//
function initCoords() {
    if (navigator.geolocation) {
        initMap();

    } else {
      alert("Location is not supported by this browser");

    }
}
