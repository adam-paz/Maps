var marker;
var infoWindow;

function initMap() {
  var options = {
    zoom:16,
    center:{lat: -33.8660001, lng: 151.2014246},
    //clickableIcons: false // disables default POI
  }
  //creates our singular map and marker
  map = new google.maps.Map(document.getElementById('map'), options);

  // infoWindow = new google.maps.InfoWindow({
  //   content:""
  // });
  // marker = new google.maps.Marker({
  //   position:{lat: -33.8660001, lng: 151.2014246},
  //   map:map,
  // });



  var watch = navigator.geolocation.watchPosition(watchMap,watchError);
  function watchMap(position){
    var currPosition;
    // if they allowed location
    map.setCenter(position.coords);
    if(position.coords){
      currPosition = {lat:position.coords.latitude,lng:position.coords.longitude};
      var clickHandler = new ClickEventHandler(map, currPosition);
      map.setCenter(currPosition);
    } else {
      console.log("Starting in Sydney");
    }
    //Center map button
    document.getElementById("centerMapBtn").onclick = function(){
      map.setCenter(currPosition);
    }
  }
  function watchError(err){
    console.warn('ERROR(' + err.code + '): ' + err.message);
  }

  // Listen for click on map
  // google.maps.event.addListener(map, 'click', function(event){
  //   geocode(event.latLng);
  // });
  //Call autocomplete for search bar
  initAutocomplete(map);
  //for map button
  map.controls[google.maps.ControlPosition.BOTTOM_LEFT].push(document.getElementById('centerMapDiv'));
}//end function initmap

//-----------------------------------------------------------------------------
//
function initAutocomplete(map) {

  // Create the search box and link it to the UI element.
  var input = document.getElementById('pac-input');
  var searchBox = new google.maps.places.SearchBox(input);
  //map.controls[google.maps.ControlPosition.BOTTOM_RIGHT].push(input);
  // Bias the SearchBox results towards current map's viewport.
  map.addListener('bounds_changed', function() {
    searchBox.setBounds(map.getBounds());
  });

  var markers = [];

  // Listen for the event fired when the user selects a prediction and retrieve
  // more details for that place.
  searchBox.addListener('places_changed', function() {
    console.log("in searchbox listener");
    var places = searchBox.getPlaces();

    if (places.length == 0) {
      return;
    }

    // Clear out the old markers.
    markers.forEach(function(marker) {
      marker.setMap(null);
    });

    // For each place, get the icon, name and location.
    var bounds = new google.maps.LatLngBounds();
    places.forEach(function(place) {
      if (!place.geometry) {
        console.log("Returned place contains no geometry");
        return;
      }

      //HAVE THE SEARCHED place
      console.log("place_id" + place.place_id);
      console.log("place name"+ place.name);
      console.log("place hours"+ place.opening_hours.open_now);




      if (place.geometry.viewport) {
        // Only geocodes have viewport.
        bounds.union(place.geometry.viewport);
      } else {
        bounds.extend(place.geometry.location);
      }
    });
    map.fitBounds(bounds);
  });
}
