let mongoose = require('mongoose');

let bathroomSchema = mongoose.Schema({
  place_id:{
    type:String,
    required:true,
  },
  name:{
    type:String,
    required:false,
  },
  address:{
    type:String,
    required:true,
  },
  rating:{
    type:Number,
    required:true,
  },
  numRatings:{
    type:Number,
    required:true,
  },
  disabled:{
    type:Boolean,
    required:true,
  },
  numCode:{
    type:Number,
    required:true,
  },
  keyRequired:{
    type:Boolean,
    required:true,
  },
  comments:{
    type:String,
    required:true,
  },
  hours:{
    type:String,
    required:true,
  }
});

let Bathroom = module.exports = mongoose.model('Bathroom', bathroomSchema);
